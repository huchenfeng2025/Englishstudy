# 英语记忆站

打开 `index.html` 即可使用。网站包含初中单词、高中单词、四级单词、雅思单词四个分类，并会按艾宾浩斯记忆曲线保存每个单词的复习时间。

## 词库来源

网站会优先从公开词典文件加载完整词库：

- Qwerty Learner 公开词典仓库：https://github.com/RealKai42/qwerty-learner
- 词典文件路径示例：https://github.com/RealKai42/qwerty-learner/tree/master/public/dicts

如果浏览器无法访问在线词库，网站会自动使用内置备用词库，保证背词功能可用。

## 导入格式

可以导入 JSON 文件扩充词库。支持下面两种常见格式：

```json
[
  {
    "word": "example",
    "translation": "n. 例子",
    "phonetic": "/ig'zampəl/"
  }
]
```

```json
[
  ["example", "n. 例子", "/ig'zampəl/"]
]
```
