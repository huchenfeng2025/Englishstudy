const STORAGE_KEY = "english-memory-progress-v2";
const CUSTOM_KEY = "english-memory-custom-decks-v1";
const PROFILE_KEY = "english-memory-profile-v1";
const INTERVALS = [
  5 * 60 * 1000,
  30 * 60 * 1000,
  24 * 60 * 60 * 1000,
  2 * 24 * 60 * 60 * 1000,
  4 * 24 * 60 * 60 * 1000,
  7 * 24 * 60 * 60 * 1000,
  15 * 24 * 60 * 60 * 1000,
  30 * 24 * 60 * 60 * 1000,
  60 * 24 * 60 * 60 * 1000,
];
const TODAY = getDayKey();

const REMOTE_DECKS = {
  junior: {
    title: "初中单词",
    target: "中考核心词汇",
    urls: [
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/ChuZhongluan_2_T.json",
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/ZhongKao_2_T.json",
    ],
  },
  senior: {
    title: "高中单词",
    target: "高考 3500 词",
    urls: [
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/GaoKao_3500.json",
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/GaoZhong_2_T.json",
    ],
  },
  cet4: {
    title: "四级单词",
    target: "CET-4 高频词",
    urls: [
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/CET4_T.json",
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/CET4_3_T.json",
    ],
  },
  ielts: {
    title: "雅思单词",
    target: "IELTS 备考词汇",
    urls: [
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/IELTS_3_T.json",
      "https://raw.githubusercontent.com/RealKai42/qwerty-learner/master/public/dicts/IELTS_T.json",
    ],
  },
};

const FALLBACK_DECKS = {
  junior: [
    ["ability", "n. 能力；才能", "/əˈbɪləti/"],
    ["accept", "v. 接受；同意", "/əkˈsept/"],
    ["achieve", "v. 实现；达到", "/əˈtʃiːv/"],
    ["activity", "n. 活动", "/ækˈtɪvəti/"],
    ["attention", "n. 注意；关注", "/əˈtenʃn/"],
    ["beautiful", "adj. 美丽的", "/ˈbjuːtɪfl/"],
    ["borrow", "v. 借入", "/ˈbɑːroʊ/"],
    ["challenge", "n./v. 挑战", "/ˈtʃælɪndʒ/"],
    ["collect", "v. 收集；集合", "/kəˈlekt/"],
    ["compare", "v. 比较", "/kəmˈper/"],
    ["continue", "v. 继续", "/kənˈtɪnjuː/"],
    ["culture", "n. 文化", "/ˈkʌltʃər/"],
  ],
  senior: [
    ["abandon", "v. 放弃；遗弃", "/əˈbændən/"],
    ["academic", "adj. 学术的", "/ˌækəˈdemɪk/"],
    ["accurate", "adj. 准确的", "/ˈækjərət/"],
    ["adapt", "v. 适应；改编", "/əˈdæpt/"],
    ["advance", "n./v. 前进；进步", "/ədˈvæns/"],
    ["analysis", "n. 分析", "/əˈnæləsɪs/"],
    ["approach", "n./v. 方法；接近", "/əˈproʊtʃ/"],
    ["attitude", "n. 态度", "/ˈætɪtuːd/"],
    ["benefit", "n./v. 好处；受益", "/ˈbenɪfɪt/"],
    ["evidence", "n. 证据", "/ˈevɪdəns/"],
    ["feature", "n./v. 特征；以……为特色", "/ˈfiːtʃər/"],
    ["essential", "adj. 必不可少的", "/ɪˈsenʃl/"],
  ],
  cet4: [
    ["absence", "n. 缺席；不存在", "/ˈæbsəns/"],
    ["acknowledge", "v. 承认；感谢", "/əkˈnɑːlɪdʒ/"],
    ["alternative", "n./adj. 替代选择；可替代的", "/ɔːlˈtɜːrnətɪv/"],
    ["appreciate", "v. 欣赏；感激；理解", "/əˈpriːʃieɪt/"],
    ["assessment", "n. 评估；评价", "/əˈsesmənt/"],
    ["commitment", "n. 承诺；投入", "/kəˈmɪtmənt/"],
    ["conflict", "n./v. 冲突", "/ˈkɑːnflɪkt/"],
    ["consistent", "adj. 一致的；连续的", "/kənˈsɪstənt/"],
    ["consumer", "n. 消费者", "/kənˈsuːmər/"],
    ["contribute", "v. 贡献；促成", "/kənˈtrɪbjuːt/"],
    ["controversial", "adj. 有争议的", "/ˌkɑːntrəˈvɜːrʃl/"],
    ["cooperate", "v. 合作", "/koʊˈɑːpəreɪt/"],
  ],
  ielts: [
    ["abolish", "v. 废除；取消", "/əˈbɑːlɪʃ/"],
    ["advocate", "v./n. 提倡；拥护者", "/ˈædvəkeɪt/"],
    ["allocate", "v. 分配；拨出", "/ˈæləkeɪt/"],
    ["ambiguous", "adj. 模棱两可的", "/æmˈbɪɡjuəs/"],
    ["analogy", "n. 类比；相似", "/əˈnælədʒi/"],
    ["assemble", "v. 集合；组装", "/əˈsembl/"],
    ["attribute", "v./n. 把……归因于；属性", "/əˈtrɪbjuːt/"],
    ["coherent", "adj. 连贯的；一致的", "/koʊˈhɪrənt/"],
    ["compile", "v. 编纂；汇编", "/kəmˈpaɪl/"],
    ["comprehensive", "adj. 全面的；综合的", "/ˌkɑːmprɪˈhensɪv/"],
    ["consensus", "n. 共识", "/kənˈsensəs/"],
    ["criterion", "n. 标准；准则", "/kraɪˈtɪriən/"],
  ],
};

const defaultProfile = {
  dailyGoal: 20,
  sessionPack: 10,
  speedMode: false,
  reviewCount: 0,
  lastStudyDate: "",
  streak: 0,
  history: {
    [TODAY]: {
      completed: 0,
      correct: 0,
      reviewed: 0,
    },
  },
};

const state = {
  decks: {},
  deckId: "junior",
  mode: "due",
  trainingMode: "recognition",
  queue: [],
  index: 0,
  revealed: false,
  spellRevealed: false,
  spellMessage: "",
  cardStartedAt: 0,
  currentWordKey: "",
  sessionDurations: [],
  progress: loadJson(STORAGE_KEY, {}),
  profile: normalizeProfile(loadJson(PROFILE_KEY, defaultProfile)),
};

const deckList = document.querySelector("#deckList");
const deckMeta = document.querySelector("#deckMeta");
const deckTitle = document.querySelector("#deckTitle");
const dueCount = document.querySelector("#dueCount");
const learnedCount = document.querySelector("#learnedCount");
const masteredCount = document.querySelector("#masteredCount");
const streakCount = document.querySelector("#streakCount");
const progressText = document.querySelector("#progressText");
const progressFill = document.querySelector("#progressFill");
const positionLabel = document.querySelector("#positionLabel");
const scheduleLabel = document.querySelector("#scheduleLabel");
const wordText = document.querySelector("#wordText");
const phoneticText = document.querySelector("#phoneticText");
const meaningText = document.querySelector("#meaningText");
const revealBtn = document.querySelector("#revealBtn");
const speakBtn = document.querySelector("#speakBtn");
const resetBtn = document.querySelector("#resetBtn");
const importFile = document.querySelector("#importFile");
const todayDone = document.querySelector("#todayDone");
const goalValue = document.querySelector("#goalValue");
const goalMinus = document.querySelector("#goalMinus");
const goalPlus = document.querySelector("#goalPlus");
const difficultCount = document.querySelector("#difficultCount");
const accuracyText = document.querySelector("#accuracyText");
const recommendationText = document.querySelector("#recommendationText");
const focusLabel = document.querySelector("#focusLabel");
const memoryTip = document.querySelector("#memoryTip");
const memoryHint = document.querySelector("#memoryHint");
const stageText = document.querySelector("#stageText");
const nextActionText = document.querySelector("#nextActionText");
const remainingCount = document.querySelector("#remainingCount");
const reviewedToday = document.querySelector("#reviewedToday");
const completionRate = document.querySelector("#completionRate");
const spellPanel = document.querySelector("#spellPanel");
const spellInput = document.querySelector("#spellInput");
const checkSpellBtn = document.querySelector("#checkSpellBtn");
const showAnswerBtn = document.querySelector("#showAnswerBtn");
const spellFeedback = document.querySelector("#spellFeedback");
const troubleWord = document.querySelector("#troubleWord");
const troubleHint = document.querySelector("#troubleHint");
const paceText = document.querySelector("#paceText");
const strengthText = document.querySelector("#strengthText");
const strategyText = document.querySelector("#strategyText");
const speedToggle = document.querySelector("#speedToggle");
const focusToggle = document.querySelector("#focusToggle");
const liveStatus = document.querySelector("#liveStatus");
const progressTrack = document.querySelector("#progressTrack");
const coreMeaning = document.querySelector("#coreMeaning");
const coreMeaningHint = document.querySelector("#coreMeaningHint");
const associationText = document.querySelector("#associationText");
const associationHint = document.querySelector("#associationHint");
const smartBriefText = document.querySelector("#smartBriefText");
const matureCheckText = document.querySelector("#matureCheckText");
const efficiencyText = document.querySelector("#efficiencyText");
const focusExitBtn = document.querySelector("#focusExitBtn");
const smartRouteBtn = document.querySelector("#smartRouteBtn");
const wordTimerText = document.querySelector("#wordTimerText");
const etaText = document.querySelector("#etaText");
const currentPaceText = document.querySelector("#currentPaceText");
const flowRecall = document.querySelector("#flowRecall");
const flowReveal = document.querySelector("#flowReveal");
const flowRate = document.querySelector("#flowRate");
const greetingOverlay = document.querySelector("#greetingOverlay");
const greetingVideo = document.querySelector("#greetingVideo");
const pageTabs = document.querySelectorAll(".page-tab");

init();
setInterval(updateLiveTiming, 1000);
setupGreeting();
setupPageTabs();

async function init() {
  bumpStreakIfNeeded();
  state.decks = createFallbackDecks();
  addCustomDecks();
  renderDeckList();
  selectDeck(state.deckId);
  await hydrateRemoteDecks();
}

function createFallbackDecks() {
  return Object.fromEntries(
    Object.entries(REMOTE_DECKS).map(([id, meta]) => [
      id,
      {
        ...meta,
        id,
        source: "备用词库",
        words: FALLBACK_DECKS[id].map(([word, translation, phonetic]) => ({
          word,
          translation,
          phonetic,
        })),
      },
    ]),
  );
}

async function hydrateRemoteDecks() {
  await Promise.all(
    Object.entries(REMOTE_DECKS).map(async ([id, meta]) => {
      const words = await fetchFirstAvailable(meta.urls);
      if (words.length) {
        state.decks[id] = {
          ...state.decks[id],
          source: "公开完整词库",
          words: normalizeWords(words),
        };
      }
    }),
  );
  renderDeckList();
  selectDeck(state.deckId);
}

async function fetchFirstAvailable(urls) {
  for (const url of urls) {
    try {
      const response = await fetch(url, { cache: "force-cache" });
      if (!response.ok) continue;
      const data = await response.json();
      const words = normalizeWords(data);
      if (words.length > 20) return words;
    } catch (error) {
      console.info("词库加载失败，尝试下一个来源", url, error);
    }
  }
  return [];
}

function normalizeWords(data) {
  const list = Array.isArray(data)
    ? data
    : Array.isArray(data.words)
      ? data.words
      : Array.isArray(data.data)
        ? data.data
        : [];

  const seen = new Set();
  return list
    .map((item) => {
      if (Array.isArray(item)) {
        return {
          word: String(item[0] || "").trim(),
          translation: String(item[1] || item[2] || "").trim(),
          phonetic: String(item[2] || item[3] || "").trim(),
        };
      }
      const word = item.word || item.name || item.en || item.content || item.headWord;
      const translation =
        item.translation ||
        item.trans ||
        item.meaning ||
        item.cn ||
        item.definition ||
        item.desc ||
        (Array.isArray(item.translations) ? item.translations.join("；") : "");
      return {
        word: String(word || "").trim(),
        translation: String(translation || "").trim(),
        phonetic: String(item.phonetic || item.ukphone || item.usphone || "").trim(),
      };
    })
    .filter((item) => {
      const key = item.word.toLowerCase();
      if (!item.word || seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function addCustomDecks() {
  const custom = loadJson(CUSTOM_KEY, {});
  Object.entries(custom).forEach(([id, deck]) => {
    state.decks[id] = {
      id,
      title: deck.title || "自定义词库",
      target: deck.target || "导入词表",
      source: "本地导入",
      words: normalizeWords(deck.words || deck),
    };
  });
}

function renderDeckList() {
  deckList.innerHTML = "";
  Object.values(state.decks).forEach((deck) => {
    const button = document.createElement("button");
    button.className = `deck-button${deck.id === state.deckId ? " is-active" : ""}`;
    button.type = "button";
    button.innerHTML = `
      <strong>${deck.title}</strong>
      <span>${deck.words.length} 词</span>
      <span>${deck.target}</span>
      <span>${deck.source}</span>
    `;
    button.addEventListener("click", () => selectDeck(deck.id));
    deckList.appendChild(button);
  });
}

function selectDeck(deckId) {
  state.deckId = deckId;
  state.index = 0;
  state.revealed = false;
  state.spellRevealed = false;
  state.spellMessage = "";
  resetCardTimer("");
  ensureDeckProgress(deckId);
  buildQueue();
  renderDeckList();
  renderCurrent();
}

function ensureDeckProgress(deckId) {
  if (!state.progress[deckId]) state.progress[deckId] = {};
}

function buildQueue() {
  const deck = state.decks[state.deckId];
  const progress = state.progress[state.deckId] || {};
  const now = Date.now();
  const words = deck.words.map((word, order) => ({ ...word, order }));
  const difficultWords = words.filter((item) => getWeakness(progress[item.word]) >= 2);
  const packSize = state.profile.speedMode
    ? Math.max(10, Math.floor(state.profile.sessionPack * 0.8))
    : state.profile.sessionPack;

  if (state.mode === "new") {
    state.queue = words.filter((item) => !progress[item.word]);
  } else if (state.mode === "all") {
    state.queue = words;
  } else if (state.mode === "weak") {
    state.queue = difficultWords.sort(sortByWeakness(progress));
  } else {
    const due = words.filter((item) => {
      const record = progress[item.word];
      return !record || record.nextReview <= now;
    });
    state.queue = due.sort(sortForReview(progress));
  }

  if (state.mode === "due" && difficultWords.length) {
    const topWeak = difficultWords
      .filter((item) => !state.queue.some((queued) => queued.word === item.word))
      .sort(sortByWeakness(progress))
      .slice(0, state.profile.speedMode ? 3 : Math.min(5, Math.ceil(state.profile.dailyGoal / 5)));
    state.queue = [...state.queue, ...topWeak];
  }

  if (state.mode === "due" && state.queue.length > Math.min(state.profile.dailyGoal, packSize)) {
    state.queue = state.queue.slice(0, Math.min(state.profile.dailyGoal, packSize));
  }

  if (state.mode !== "due" && state.queue.length > packSize) {
    state.queue = state.queue.slice(0, packSize);
  }

  if (state.index >= state.queue.length) state.index = 0;
}

function getDeckSnapshot() {
  const deck = state.decks[state.deckId];
  const progress = state.progress[state.deckId] || {};
  const now = Date.now();
  const due = deck.words.filter((item) => !progress[item.word] || progress[item.word].nextReview <= now).length;
  const dueReview = deck.words.filter((item) => progress[item.word] && progress[item.word].nextReview <= now).length;
  const difficult = deck.words.filter((item) => getWeakness(progress[item.word]) >= 2).length;
  const newWords = deck.words.filter((item) => !progress[item.word]).length;
  return { deck, progress, due, dueReview, difficult, newWords };
}

function chooseSmartMode() {
  const { dueReview, difficult, newWords } = getDeckSnapshot();
  const todayStats = getTodayStats();
  const accuracy = todayStats.reviewed ? todayStats.correct / todayStats.reviewed : 1;
  if (dueReview > 0) return "due";
  if (todayStats.reviewed >= 8 && accuracy < 0.58 && difficult > 0) return "weak";
  if (difficult >= 6) return "weak";
  if (newWords > 0) return "new";
  if (difficult > 0) return "weak";
  return "all";
}

function setMode(mode, shouldAnnounce = false) {
  document.querySelectorAll(".mode-tab").forEach((tab) => {
    const active = tab.dataset.mode === mode;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-selected", String(active));
  });
  state.mode = mode;
  state.index = 0;
  state.revealed = false;
  state.spellRevealed = false;
  state.spellMessage = "";
  resetCardTimer("");
  buildQueue();
  renderCurrent();
  if (shouldAnnounce) announce(`已切换到${getModeLabel(mode)}。`);
}

function getModeLabel(mode) {
  return {
    due: "复习",
    new: "新词",
    weak: "薄弱",
    all: "全部",
  }[mode] || "学习";
}

function enqueueMatureCheck(word) {
  const progress = state.progress[state.deckId];
  const record = progress[word];
  if (!record) return;
  record.matureCheckAt = state.profile.reviewCount + 50;
  record.matureCheckDone = false;
}

function pullMatureCheckWords() {
  const deck = state.decks[state.deckId];
  const progress = state.progress[state.deckId] || {};
  const queued = new Set(state.queue.slice(state.index).map((item) => item.word));
  const ready = deck.words.filter((item) => {
    const record = progress[item.word];
    return (
      record &&
      record.matureCheckAt &&
      !record.matureCheckDone &&
      record.matureCheckAt <= state.profile.reviewCount &&
      !queued.has(item.word)
    );
  });

  if (!ready.length) return;
  ready.forEach((item) => {
    state.queue.splice(Math.min(state.index + 1, state.queue.length), 0, {
      ...item,
      reviewReason: "mature-check",
    });
  });
}

function resetCardTimer(wordKey) {
  state.currentWordKey = wordKey;
  state.cardStartedAt = Date.now();
}

function getCardElapsedSeconds() {
  if (!state.cardStartedAt) return 0;
  return Math.max(0, Math.round((Date.now() - state.cardStartedAt) / 1000));
}

function recordCardDuration() {
  const elapsed = getCardElapsedSeconds();
  if (!elapsed) return;
  state.sessionDurations.push(Math.min(elapsed, 60));
  if (state.sessionDurations.length > 30) state.sessionDurations.shift();
}

function getAverageCardSeconds() {
  if (!state.sessionDurations.length) return state.profile.speedMode ? 4 : 7;
  const total = state.sessionDurations.reduce((sum, seconds) => sum + seconds, 0);
  return Math.max(3, Math.round(total / state.sessionDurations.length));
}

function updateLiveTiming() {
  if (!wordTimerText || !etaText || !currentPaceText) return;
  const remaining = state.queue.length ? Math.max(state.queue.length - state.index, 0) : 0;
  const averageSeconds = getAverageCardSeconds();
  const etaMinutes = remaining ? Math.max(1, Math.ceil((remaining * averageSeconds) / 60)) : 0;
  const elapsed = getCardElapsedSeconds();
  wordTimerText.textContent = `${elapsed} 秒`;
  etaText.textContent = etaMinutes ? `${etaMinutes} 分钟` : "--";
  currentPaceText.textContent = buildCurrentPaceText(elapsed, averageSeconds);
  updateRecallFlow(state.queue[state.index], elapsed);
}

function getMatureCheckSummary(progress) {
  const waiting = Object.values(progress).filter(
    (record) => record.matureCheckAt && !record.matureCheckDone,
  );
  if (!waiting.length) {
    return {
      count: 0,
      text: "暂无等待复检的词",
    };
  }
  const nearest = Math.min(
    ...waiting.map((record) => Math.max(record.matureCheckAt - state.profile.reviewCount, 0)),
  );
  return {
    count: waiting.length,
    text: nearest === 0 ? `${waiting.length} 个熟练词现在复检` : `${waiting.length} 个词等待，最快还差 ${nearest} 词`,
  };
}

function renderCurrent() {
  const deck = state.decks[state.deckId];
  const progress = state.progress[state.deckId] || {};
  const now = Date.now();
  const records = Object.values(progress);
  const due = deck.words.filter((item) => !progress[item.word] || progress[item.word].nextReview <= now).length;
  const newWords = deck.words.filter((item) => !progress[item.word]).length;
  const mastered = records.filter((record) => record.level >= INTERVALS.length - 1).length;
  const learnedRate = deck.words.length ? Math.round((records.length / deck.words.length) * 100) : 0;
  const difficult = deck.words.filter((item) => getWeakness(progress[item.word]) >= 2).length;
  const todayStats = getTodayStats();
  const todayAccuracy = todayStats.reviewed ? Math.round((todayStats.correct / todayStats.reviewed) * 100) : 0;
  const completion = state.profile.dailyGoal
    ? Math.min(100, Math.round((todayStats.completed / state.profile.dailyGoal) * 100))
    : 0;
  const hardest = getHardestWord(progress);
  const current = state.queue[state.index];
  const matureCheck = getMatureCheckSummary(progress);
  const reviewedInPack = state.queue.length ? Math.min(state.index, state.queue.length) : 0;
  const currentKey = current ? `${state.deckId}:${current.word}:${state.index}` : "";
  if (currentKey !== state.currentWordKey) resetCardTimer(currentKey);
  const remainingInPack = state.queue.length ? Math.max(state.queue.length - state.index, 0) : 0;
  const averageSeconds = getAverageCardSeconds();
  const etaMinutes = remainingInPack ? Math.max(1, Math.ceil((remainingInPack * averageSeconds) / 60)) : 0;

  deckMeta.textContent = `${deck.target} · ${deck.source}`;
  deckTitle.textContent = deck.title;
  dueCount.textContent = due;
  learnedCount.textContent = records.length;
  masteredCount.textContent = mastered;
  streakCount.textContent = state.profile.streak;
  todayDone.textContent = todayStats.completed;
  goalValue.textContent = state.profile.dailyGoal;
  difficultCount.textContent = difficult;
  accuracyText.textContent = `${todayAccuracy}%`;
  progressText.textContent = `${learnedRate}%`;
  progressFill.style.width = `${learnedRate}%`;
  progressTrack.setAttribute("aria-valuenow", String(learnedRate));
  remainingCount.textContent = remainingInPack;
  reviewedToday.textContent = todayStats.reviewed;
  completionRate.textContent = `${completion}%`;
  smartBriefText.textContent = buildSmartBriefText(due, difficult, todayStats, current, newWords);
  matureCheckText.textContent = matureCheck.text;
  efficiencyText.textContent = state.queue.length
    ? `已过 ${reviewedInPack} 词，还剩 ${remainingInPack} 词`
    : "这一轮已清空";
  wordTimerText.textContent = `${getCardElapsedSeconds()} 秒`;
  etaText.textContent = etaMinutes ? `${etaMinutes} 分钟` : "--";
  currentPaceText.textContent = buildCurrentPaceText(getCardElapsedSeconds(), averageSeconds);
  updateRecallFlow(current);
  troubleWord.textContent = hardest?.word || "暂无";
  troubleHint.textContent = hardest
    ? `已记录 ${hardest.score} 点薄弱值，建议在薄弱模式多压几轮。`
    : "当前没有明显反复出错的词，继续保持节奏。";
  paceText.textContent = `当前节奏：${state.profile.speedMode ? "极速冲刺" : "标准学习"} · 单轮 ${state.profile.sessionPack} 词`;
  strategyText.textContent = state.profile.speedMode
    ? "策略：先过核心队列，错词快速回流"
    : "策略：到期优先，再压薄弱词";
  speedToggle.textContent = state.profile.speedMode ? "极速开启" : "极速关闭";
  speedToggle.classList.toggle("is-on", state.profile.speedMode);
  speedToggle.setAttribute("aria-pressed", String(state.profile.speedMode));
  syncFocusButtons();
  focusLabel.textContent = state.mode === "weak" ? "薄弱词强化" : due ? "优先复习" : "适合学新词";
  recommendationText.textContent = buildRecommendationText(due, difficult, deck.words.length);
  positionLabel.textContent = state.queue.length ? `${state.index + 1} / ${state.queue.length}` : "0 / 0";

  if (!current) {
    wordText.textContent = state.mode === "due" ? "今日完成" : "当前模式为空";
    phoneticText.textContent = "";
    meaningText.textContent =
      state.mode === "due"
        ? "当前没有需要马上复习的单词，可以切换到新词模式继续推进。"
        : "这个模式下暂时没有可学习的单词。";
    meaningText.classList.remove("is-hidden");
    revealBtn.disabled = true;
    speakBtn.disabled = true;
    scheduleLabel.textContent = "暂无安排";
    memoryTip.textContent = "今天的节奏不错。";
    memoryHint.textContent = "如果精力还在，可以转到新词模式继续积累。";
    stageText.textContent = "已完成一轮";
    nextActionText.textContent = "切换模式，或者明天回来继续复习。";
    strengthText.textContent = "记忆强度：等待下一轮";
    coreMeaning.textContent = "先翻开一个词，开始今天的记忆。";
    coreMeaningHint.textContent = "先抓住最核心的中文意思，不要一开始就试图全记住。";
    associationText.textContent = "把单词放进你今天会说的一句话里。";
    associationHint.textContent = "越贴近自己的生活场景，长期记忆越稳。";
    updateTrainingSurface(null, null);
    return;
  }

  const record = progress[current.word];
  const weakness = getWeakness(record);
  const memoryStrength = getMemoryStrength(record, weakness);
  const hideAnswerForSpelling = state.trainingMode === "spelling" && !state.spellRevealed;
  wordText.classList.toggle("prompt-word", hideAnswerForSpelling);
  wordText.textContent = hideAnswerForSpelling ? extractCoreMeaning(current.translation) : current.word;
  phoneticText.textContent = hideAnswerForSpelling ? "" : current.phonetic || "";
  meaningText.textContent = current.translation || "暂无释义，可通过导入词库补充。";
  meaningText.classList.toggle("is-hidden", !state.revealed);
  revealBtn.textContent = state.revealed ? "隐藏释义" : "显示释义";
  revealBtn.disabled = false;
  speakBtn.disabled = false;
  scheduleLabel.textContent =
    current.reviewReason === "mature-check"
      ? "熟练复检：确认是真会"
      : record
        ? `下次复习：${formatTime(record.nextReview)}`
        : "新词";
  memoryTip.textContent = buildMemoryTip(record, weakness);
  memoryHint.textContent = buildMemoryHint(record, current);
  stageText.textContent = buildStageText(record, weakness);
  strengthText.textContent = `记忆强度：${memoryStrength}`;
  coreMeaning.textContent = extractCoreMeaning(current.translation);
  coreMeaningHint.textContent = buildCoreMeaningHint(record, current);
  const shouldHideEnglish = state.trainingMode === "spelling" && !state.spellRevealed;
  associationText.textContent = shouldHideEnglish
    ? "只看中文释义，先在脑中想出英文拼写。"
    : buildAssociationText(current);
  associationHint.textContent = shouldHideEnglish
    ? "答题前不显示英文，避免变成抄写。"
    : buildAssociationHint(record);
  nextActionText.textContent = state.revealed
    ? "用 1 到 4 快速判断记忆程度，系统会自动安排下次出现时间。"
    : "先自己回忆意思，再翻开释义，记忆效果会更好。";

  if (state.profile.speedMode && state.trainingMode === "recognition") {
    nextActionText.textContent = state.revealed
      ? "直接按 1 到 4 给分，保持节奏不要停。"
      : "先心里作答，马上翻面，不要在一个词上停太久。";
  }

  updateTrainingSurface(current, record);
}

function rateCurrent(rating) {
  const current = state.queue[state.index];
  if (!current) return;
  recordCardDuration();

  const progress = state.progress[state.deckId];
  const old = progress[current.word] || {
    level: -1,
    seen: 0,
    wrongCount: 0,
    hardCount: 0,
    correctCount: 0,
    lastRating: "",
  };

  let nextLevel = old.level;
  if (current.reviewReason === "mature-check" && rating === "easy") {
    progress[current.word] = {
      ...old,
      matureCheckDone: true,
      matureCheckAt: 0,
      lastRating: rating,
      lastReview: Date.now(),
      nextReview: Date.now() + INTERVALS[Math.min(old.level + 1, INTERVALS.length - 1)],
      seen: old.seen + 1,
      correctCount: old.correctCount + 1,
    };
    state.profile.reviewCount += 1;
    updateTodayStats(rating);
    saveJson(STORAGE_KEY, state.progress);
    saveJson(PROFILE_KEY, state.profile);
    announce(`熟练复检已完成，${current.word} 已进入下一轮。`);
    state.index += 1;
    state.revealed = false;
    state.spellRevealed = false;
    state.spellMessage = "";
    pullMatureCheckWords();
    if (state.index >= state.queue.length) buildQueue();
    renderCurrent();
    return;
  }

  if (rating === "again") nextLevel = 0;
  if (rating === "hard") nextLevel = Math.max(1, old.level);
  if (rating === "good") nextLevel = Math.min(old.level + 1, INTERVALS.length - 1);
  if (rating === "easy") nextLevel = Math.min(old.level + 2, INTERVALS.length - 1);

  progress[current.word] = {
    level: nextLevel,
    seen: old.seen + 1,
    wrongCount: old.wrongCount + (rating === "again" ? 1 : 0),
    hardCount: old.hardCount + (rating === "hard" ? 1 : 0),
    correctCount: old.correctCount + (rating === "good" || rating === "easy" ? 1 : 0),
    lastRating: rating,
    lastReview: Date.now(),
    nextReview: Date.now() + INTERVALS[nextLevel],
    matureCheckAt: rating === "easy" ? old.matureCheckAt || 0 : 0,
    matureCheckDone: rating === "easy" ? old.matureCheckDone || false : true,
  };

  state.profile.reviewCount += 1;
  if (rating === "easy" && current.reviewReason !== "mature-check") {
    enqueueMatureCheck(current.word);
    announce(`${current.word} 已标记熟练，50 个评分后会复检一次。`);
  } else {
    announce(`已记录 ${current.word} 的记忆反馈。`);
  }

  updateTodayStats(rating);
  saveJson(STORAGE_KEY, state.progress);
  saveJson(PROFILE_KEY, state.profile);

  state.index += 1;
  state.revealed = false;
  state.spellRevealed = false;
  state.spellMessage = "";

  if ((rating === "again" || rating === "hard") && state.mode !== "weak") {
    state.queue.push(current);
  }

  pullMatureCheckWords();

  if (state.index >= state.queue.length) {
    buildQueue();
  }
  renderCurrent();
}

function updateTrainingSurface(current, record) {
  const spellingMode = state.trainingMode === "spelling";
  spellPanel.classList.toggle("is-hidden", !spellingMode || !current);
  spellInput.classList.toggle("is-hidden", !spellingMode || !current);
  meaningText.classList.toggle("is-hidden", spellingMode || !state.revealed);
  revealBtn.classList.toggle("is-hidden", spellingMode);

  if (!spellingMode) return;

  if (!current) {
    spellFeedback.textContent = "当前没有可练习的单词。";
    spellInput.value = "";
    spellInput.disabled = true;
    checkSpellBtn.disabled = true;
    showAnswerBtn.disabled = true;
    return;
  }

  spellInput.disabled = false;
  checkSpellBtn.disabled = false;
  showAnswerBtn.disabled = false;
  if (!state.spellRevealed) spellInput.value = "";
  spellFeedback.textContent = state.spellMessage || (state.spellRevealed
    ? `答案是 ${current.word}，读一遍再继续。`
    : record
      ? "只看中文释义，试着把完整英文拼出来。"
      : "只看中文释义，这是第一次练习。");
}

function getHardestWord(progress) {
  return Object.entries(progress)
    .map(([word, record]) => ({ word, score: getWeakness(record) }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)[0];
}

function getMemoryStrength(record, weakness) {
  if (!record) return "刚开始";
  if (weakness >= 3) return "易遗忘";
  if (record.level <= 1) return "短时记忆";
  if (record.level <= 4) return "正在稳固";
  return "比较牢固";
}

function getWeakness(record) {
  if (!record) return 0;
  return record.wrongCount * 2 + record.hardCount - Math.floor(record.correctCount / 3);
}

function sortForReview(progress) {
  return (a, b) => {
    const aRecord = progress[a.word];
    const bRecord = progress[b.word];
    const aTime = aRecord?.nextReview || 0;
    const bTime = bRecord?.nextReview || 0;
    const weakGap = getWeakness(bRecord) - getWeakness(aRecord);
    return aTime - bTime || weakGap || a.order - b.order;
  };
}

function sortByWeakness(progress) {
  return (a, b) => {
    const weakGap = getWeakness(progress[b.word]) - getWeakness(progress[a.word]);
    return weakGap || a.order - b.order;
  };
}

function buildRecommendationText(due, difficult, total) {
  if (!total) return "当前词库还是空的，可以先导入一份词表。";
  if (state.profile.speedMode && due > 0) return `极速模式已开启，当前优先清掉 ${due} 个到期词，错词会快速回流。`;
  if (due > 0 && difficult > 0) return `有 ${due} 个到期词，另有 ${difficult} 个薄弱词值得优先巩固。`;
  if (due > 0) return `今天先把 ${due} 个到期词复习掉，再补一点新词会更稳。`;
  if (difficult > 0) return `到期词不多，适合转到薄弱模式，把容易忘的词再压一遍。`;
  return "节奏很好，可以继续推进新词，保持每天稳定输入。";
}

function buildSmartBriefText(due, difficult, todayStats, current, newWords) {
  if (!current) return "这一轮已经清完，可以切新词或休息。";
  if (state.trainingMode === "spelling") return "只看中文拼写，拼完再看答案。";
  if (state.profile.speedMode) return "3 秒内判断会不会，不纠结单个词。";
  if (todayStats.reviewed >= 8 && todayStats.correct / todayStats.reviewed < 0.55) {
    return "先暂停新词，回到薄弱词巩固一轮。";
  }
  if (difficult >= 6) return "薄弱词偏多，优先用忘记和模糊真实反馈。";
  if (newWords > 0 && state.mode === "new") return "新词只抓核心义，别一开始背太满。";
  if (due > 0) return "先清到期词，翻卡前心里说出中文。";
  return "适合补新词，每个词只抓一个核心意思。";
}

function buildCurrentPaceText(elapsed, averageSeconds) {
  if (!state.queue.length) return "完成后休息 2 分钟";
  if (state.trainingMode === "spelling" && !state.spellRevealed) return "先拼完整，再看答案";
  if (elapsed <= 2) return "先在心里作答";
  if (elapsed <= 8) return `节奏很好，均速 ${averageSeconds} 秒`;
  if (elapsed <= 15) return "可以翻卡评分了";
  return "别卡太久，先给真实反馈";
}

function updateRecallFlow(current, elapsed = getCardElapsedSeconds()) {
  const hasCurrent = Boolean(current);
  const revealDone = state.trainingMode === "spelling" ? state.spellRevealed : state.revealed;
  flowRecall.classList.toggle("is-active", hasCurrent && !revealDone && elapsed < 3);
  flowReveal.classList.toggle("is-active", hasCurrent && !revealDone && elapsed >= 3);
  flowRate.classList.toggle("is-active", hasCurrent && revealDone);
  flowRecall.classList.toggle("is-done", hasCurrent && revealDone);
  flowReveal.classList.toggle("is-done", hasCurrent && revealDone);
}

function extractCoreMeaning(translation = "") {
  if (!translation) return "先翻开释义，抓住一个最核心的中文义项。";
  const cleaned = translation
    .replace(/\b(n|v|adj|adv|prep|pron|conj|interj|num|art|aux|vi|vt)\.?\s*/gi, "")
    .replace(/[a-zA-Z/()[\]'-]+/g, "")
    .replace(/\s+/g, " ")
    .trim();
  const first = cleaned.split(/[；;,.，。]/).map((item) => item.trim()).find(Boolean);
  return first || "根据中文释义回忆英文拼写。";
}

function buildCoreMeaningHint(record, current) {
  if (!record) return `第一次记 ${current.word} 时，只要先记住一个最常用意思就够了。`;
  if (record.lastRating === "again") return "上次刚忘过，这次先只抓最熟悉的那一个意思。";
  if (record.level >= 5) return "已经比较熟了，试着不看释义直接说出中文。";
  return "不要一下背太多义项，先把最常见的意思记牢。";
}

function buildAssociationText(current) {
  return `试着用 ${current.word} 造一个和你今天有关的小句子。`;
}

function buildAssociationHint(record) {
  if (!record) return "场景越具体，越容易进长期记忆。";
  if (record.lastRating === "hard" || record.lastRating === "again") return "如果总记不住，就把它放进一个你会亲口说的话里。";
  return "不用写很复杂，越自然越好。";
}

function buildMemoryTip(record, weakness) {
  if (!record) return "第一次见面时，先记住词形和一个核心意思。";
  if (weakness >= 3) return "这是你的薄弱词，建议先回忆，再开释义，再朗读一遍。";
  if (record.level <= 1) return "这个词还在早期记忆阶段，短间隔重复最有效。";
  if (record.level >= 6) return "已经进入长期记忆区，只要保持稳定复习就够了。";
  return "这一轮重点是快速提取，不必反复盯着释义。";
}

function buildMemoryHint(record, current) {
  if (!record) return `把 ${current.word} 放进一个你熟悉的场景里，会更容易记住。`;
  if (record.lastRating === "again") return "上次刚忘过，优先确保这次能独立回忆出来。";
  if (record.lastRating === "hard") return "如果感觉模糊，先抓住一个最核心的中文义项。";
  return "看完释义后，用自己的中文复述一遍，记忆会更牢。";
}

function buildStageText(record, weakness) {
  if (!record) return "新词启动";
  if (weakness >= 3) return "需要强化";
  if (record.level <= 1) return "短时巩固";
  if (record.level <= 4) return "稳定积累";
  return "长期记忆";
}

function formatTime(timestamp) {
  const diff = timestamp - Date.now();
  if (diff <= 0) return "现在";
  const minute = 60 * 1000;
  const hour = 60 * minute;
  const day = 24 * hour;
  if (diff < hour) return `${Math.ceil(diff / minute)} 分钟后`;
  if (diff < day) return `${Math.ceil(diff / hour)} 小时后`;
  return `${Math.ceil(diff / day)} 天后`;
}

function normalizeProfile(profile) {
  return {
    ...defaultProfile,
    ...profile,
    history: {
      ...defaultProfile.history,
      ...(profile.history || {}),
    },
  };
}

function getDayKey(offset = 0) {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getTodayStats() {
  if (!state.profile.history[TODAY]) {
    state.profile.history[TODAY] = { completed: 0, correct: 0, reviewed: 0 };
  }
  return state.profile.history[TODAY];
}

function bumpStreakIfNeeded() {
  const today = TODAY;
  const yesterday = getDayKey(-1);
  if (state.profile.lastStudyDate === today) return;
  if (state.profile.lastStudyDate === yesterday) {
    state.profile.streak += 1;
  } else {
    state.profile.streak = 1;
  }
  state.profile.lastStudyDate = today;
  saveJson(PROFILE_KEY, state.profile);
}

function updateTodayStats(rating) {
  const stats = getTodayStats();
  stats.reviewed += 1;
  stats.completed += 1;
  if (rating === "good" || rating === "easy") stats.correct += 1;
}

function loadJson(key, fallback) {
  try {
    return JSON.parse(localStorage.getItem(key)) || fallback;
  } catch {
    return fallback;
  }
}

function saveJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

document.querySelectorAll(".mode-tab").forEach((button) => {
  button.addEventListener("click", () => {
    setMode(button.dataset.mode);
  });
});

function setupPageTabs() {
  document.body.classList.add("page-home");
  pageTabs.forEach((button) => {
    button.addEventListener("click", () => {
      const page = button.dataset.page;
      document.body.classList.toggle("page-home", page === "home");
      document.body.classList.toggle("page-study", page === "study");
      pageTabs.forEach((tab) => {
        const active = tab === button;
        tab.classList.toggle("is-active", active);
        tab.setAttribute("aria-selected", String(active));
      });
    });
  });
}

document.querySelectorAll(".memory-button").forEach((button) => {
  button.addEventListener("click", () => rateCurrent(button.dataset.rating));
});

revealBtn.addEventListener("click", () => {
  state.revealed = !state.revealed;
  renderCurrent();
});

document.querySelectorAll(".training-tab").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".training-tab").forEach((tab) => {
      tab.classList.remove("is-active");
      tab.setAttribute("aria-selected", "false");
    });
    button.classList.add("is-active");
    button.setAttribute("aria-selected", "true");
    state.trainingMode = button.dataset.training;
    state.revealed = false;
    state.spellRevealed = false;
    state.spellMessage = "";
    renderCurrent();
    if (state.trainingMode === "spelling" && !spellInput.disabled) {
      spellInput.focus();
    }
  });
});

document.querySelectorAll(".session-chip").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".session-chip").forEach((chip) => {
      chip.classList.remove("is-active");
      chip.setAttribute("aria-selected", "false");
    });
    button.classList.add("is-active");
    button.setAttribute("aria-selected", "true");
    state.profile.sessionPack = Number(button.dataset.pack);
    saveJson(PROFILE_KEY, state.profile);
    state.index = 0;
    buildQueue();
    renderCurrent();
  });
});

speakBtn.addEventListener("click", () => {
  const current = state.queue[state.index];
  if (!current || !window.speechSynthesis) return;
  const utterance = new SpeechSynthesisUtterance(current.word);
  utterance.lang = "en-US";
  utterance.rate = 0.82;
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
});

goalMinus.addEventListener("click", () => {
  state.profile.dailyGoal = Math.max(10, state.profile.dailyGoal - 5);
  saveJson(PROFILE_KEY, state.profile);
  buildQueue();
  renderCurrent();
});

goalPlus.addEventListener("click", () => {
  state.profile.dailyGoal = Math.min(100, state.profile.dailyGoal + 5);
  saveJson(PROFILE_KEY, state.profile);
  buildQueue();
  renderCurrent();
});

speedToggle.addEventListener("click", () => {
  state.profile.speedMode = !state.profile.speedMode;
  saveJson(PROFILE_KEY, state.profile);
  state.index = 0;
  resetCardTimer("");
  buildQueue();
  renderCurrent();
});

smartRouteBtn.addEventListener("click", () => {
  const nextMode = chooseSmartMode();
  setMode(nextMode, true);
});

focusToggle.addEventListener("click", () => {
  setFocusMode(!document.body.classList.contains("focus-mode"));
});

focusExitBtn.addEventListener("click", () => {
  setFocusMode(false);
});

resetBtn.addEventListener("click", () => {
  const deck = state.decks[state.deckId];
  if (!confirm(`确定重置“${deck.title}”的学习进度吗？`)) return;
  state.progress[state.deckId] = {};
  saveJson(STORAGE_KEY, state.progress);
  state.index = 0;
  state.revealed = false;
  state.spellRevealed = false;
  state.spellMessage = "";
  buildQueue();
  renderCurrent();
});

checkSpellBtn.addEventListener("click", () => {
  const current = state.queue[state.index];
  if (!current) return;
  const typed = spellInput.value.trim().toLowerCase();
  const answer = current.word.trim().toLowerCase();
  if (!typed) {
    state.spellMessage = "先试着拼一下，再检查。";
    spellFeedback.textContent = state.spellMessage;
    return;
  }
  if (typed === answer) {
    state.spellMessage = "拼写正确，可以直接按 3 或 4 继续。";
    state.revealed = true;
    state.spellRevealed = true;
  } else {
    state.spellMessage = `差一点，正确答案是 ${current.word}。先读一遍再继续。`;
    state.spellRevealed = true;
  }
  renderCurrent();
});

showAnswerBtn.addEventListener("click", () => {
  const current = state.queue[state.index];
  if (!current) return;
  state.spellRevealed = true;
  state.spellMessage = `答案是 ${current.word}，先读一遍再评价自己。`;
  renderCurrent();
});

importFile.addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    const json = JSON.parse(await file.text());
    const words = normalizeWords(json);
    if (!words.length) throw new Error("没有识别到单词");
    const id = `custom-${Date.now()}`;
    const custom = loadJson(CUSTOM_KEY, {});
    custom[id] = {
      title: file.name.replace(/\.json$/i, ""),
      target: "本地导入词表",
      words,
    };
    saveJson(CUSTOM_KEY, custom);
    state.decks[id] = {
      id,
      title: custom[id].title,
      target: custom[id].target,
      source: "本地导入",
      words,
    };
    selectDeck(id);
  } catch (error) {
    alert(`导入失败：${error.message}`);
  } finally {
    event.target.value = "";
  }
});

spellInput.addEventListener("keydown", (event) => {
  if (event.code !== "Enter") return;
  event.preventDefault();
  checkSpellBtn.click();
});

document.addEventListener("keydown", (event) => {
  const tag = document.activeElement?.tagName;
  if (tag === "INPUT" || tag === "TEXTAREA") return;

  if (event.code === "Space") {
    event.preventDefault();
    if (state.trainingMode === "recognition" && !revealBtn.disabled) {
      state.revealed = !state.revealed;
      renderCurrent();
    }
  }

  const ratingMap = {
    Digit1: "again",
    Digit2: "hard",
    Digit3: "good",
    Digit4: "easy",
  };

  if (ratingMap[event.code]) {
    event.preventDefault();
    rateCurrent(ratingMap[event.code]);
  }

  if (state.trainingMode === "spelling" && event.code === "Enter") {
    event.preventDefault();
    checkSpellBtn.click();
  }
});

function announce(message) {
  if (!liveStatus) return;
  liveStatus.textContent = message;
}

function setupGreeting() {
  if (!greetingOverlay) return;
  let dismissed = false;
  const dismiss = () => {
    if (dismissed) return;
    dismissed = true;
    greetingOverlay.classList.add("is-hidden");
    greetingOverlay.setAttribute("aria-hidden", "true");
    setTimeout(() => greetingOverlay.remove(), 420);
  };

  greetingOverlay.addEventListener("click", dismiss);
  greetingVideo?.addEventListener("ended", dismiss);
  greetingVideo?.addEventListener("error", dismiss);
  document.addEventListener("keydown", dismiss, { once: true });
  setTimeout(dismiss, 4000);
}

function setFocusMode(enabled) {
  document.body.classList.toggle("focus-mode", enabled);
  syncFocusButtons();
  announce(enabled ? "已进入专注模式。" : "已退出专注模式。");
}

function syncFocusButtons() {
  const enabled = document.body.classList.contains("focus-mode");
  focusToggle.classList.toggle("is-on", enabled);
  focusToggle.setAttribute("aria-pressed", String(enabled));
  focusToggle.textContent = enabled ? "退出专注" : "专注";
}
